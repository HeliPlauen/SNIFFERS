ss
==

Simple windows sniffer based on raw sockets